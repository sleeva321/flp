package com.cg.service;



import com.cg.model.Product;
public interface DiscountService {
public float DicountCalculation(Product product);
}
