
/*@Service
public class InvoiceServiceImpl implements IinvoiceService {
	@Autowired
	IinvoiceRepo dao;

	static Scanner sc = new Scanner(System.in);

	@Override
	public Invoice createInvoice(Invoice obj) {

//		obj.setId((int )(Math.random() * 1000 + 1));
//		double d=5*obj.getDistance()*obj.getWeight();
//		obj.setCgst(0.035*d);
//		obj.setSgst(0.035*d);
//		double amt=obj.getCgst()+obj.getSgst()+d;
//		
//		obj.setAmount(amt);obj.getProd_Id();
		
		double d = ((obj.getProd_Discount() * obj.getProd_Price()) / 100);
		obj.setProd_ConPrice(obj.getProd_Price() - d);
		double du = (obj.getProd_Tax() * obj.getProd_ConPrice()) / 100;
		double amt = (obj.getProd_ConPrice()) + du + (obj.getProd_Deliverycharges());
		obj.setProd_FinalPrice(amt);

		return dao.save(obj);
	}

	@Override
	public Invoice updateInvoice(Invoice obj, int id) {

		Optional<Invoice> obj1 = dao.findById(id);
		if (obj1.isPresent()) {
			Invoice i = obj1.get();
//			i.setDistance(obj.getDistance());
//			i.setWeight(obj.getWeight());
//			double d=5*obj.getDistance()*obj.getWeight();
//			obj.setCgst(0.035*d);
//			obj.setSgst(0.035*d);
//			double amt=obj.getCgst()+obj.getSgst()+d;
//			
//			obj.setAmount(amt);
			i.setProd_Discount((int) obj.getProd_Discount());
			i.setProd_Promo(obj.getProd_Promo());
			double d = ((obj.getProd_Discount() * obj.getProd_Price()) / 100);
			obj.setProd_ConPrice(obj.getProd_Price() - d);
			double du = (obj.getProd_Tax() * obj.getProd_ConPrice()) / 100;
			double amt = (obj.getProd_ConPrice()) + du + (obj.getProd_Deliverycharges());
			obj.setProd_FinalPrice(amt);
			

			dao.save(i);
			return i;
		}
		return null;

	}



}*/
package com.cg.service;

import java.sql.Date;
import java.time.LocalDate;
import javax.persistence.DiscriminatorColumn;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.model.Discount;
import com.cg.model.Product;
import com.cg.dao.DiscountRepo;
import com.cg.dao.DiscountRepo2;

@Service
public class ApplyDiscountImpl implements ApplyDiscountInterface {
	@Autowired
	DiscountRepo repo;
	@Autowired
	DiscountRepo2 repo2;
	private Product product;

	@Override
public Product discountDB(Product product) {
		int id = product.getId();
	Discount discount = product.getDiscount();
	Product product1 = repo2.getOne(id);
    discount.setStartTime(Date.valueOf(LocalDate.now()));
	discount = repo.save(discount);
	product1.setDiscount(
			discount); /* product.setdiscount(discount.getId) */
repo2.save(product1);

	return product1;
}

	@Override
	public Product discountDB(int id, Discount discount) {
		int id1 = product.getId();
		Discount discount1 = product.getDiscount();
		Product product1 = repo2.getOne(id1);
	    discount1.setStartTime(Date.valueOf(LocalDate.now()));
		discount1 = repo.save(discount1);
		product1.setDiscount(
				discount1); /* product.setdiscount(discount.getId) */
	repo2.save(product1);

		return product1;
		
	}

	
}
