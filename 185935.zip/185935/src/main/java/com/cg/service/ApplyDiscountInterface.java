
package com.cg.service;

import com.cg.model.Discount;
import com.cg.model.Product;
public interface ApplyDiscountInterface {
public Product discountDB(int id, Discount discount);
Product discountDB(Product product);
}
