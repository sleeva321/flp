
package com.cg.dao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.cg.model.Discount;
import com.cg.model.Product;
public interface DiscountRepo2 extends JpaRepository<Product,Integer>{
}