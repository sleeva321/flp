package com.cg.dao;

/*import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.bean.Invoice;

@Repository
public interface IinvoiceRepo extends JpaRepository<Invoice, Integer> {

	Optional<Invoice> findById(int id);

	
}*/







import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.model.Discount;
public interface DiscountRepo extends JpaRepository<Discount,Integer>{
}
