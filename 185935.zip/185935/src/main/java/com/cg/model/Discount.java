

/*import javax.persistence.Entity;
import javax.persistence.Id;


@Entity

public class Invoice {

	@Id
	private int Prod_Id;
	private String Prod_Category;
	private String Prod_Type;
	private String Prod_SubType;
	private String Prod_Brand;
	private String Prod_Description;
	private double Prod_Price;
	private double Prod_Discount;
	private double Prod_ConPrice;
	private double Prod_Quantity;
	private String Prod_Promo;
	private double Prod_Tax;
	private double Prod_Deliverycharges;
	private double Prod_FinalPrice;

	public Invoice() {
		super();
	}

	public Invoice(int prod_Id, String prod_Category, String prod_Type, String prod_SubType, String prod_Brand,
			String prod_Description, double prod_Price, int prod_Discount, double prod_ConPrice, int prod_Quantity,
			String prod_Promo, int prod_Tax, int prod_Deliverycharges, double prod_FinalPrice) {
		super();
		Prod_Id = prod_Id;
		Prod_Category = prod_Category;
		Prod_Type = prod_Type;
		Prod_SubType = prod_SubType;
		Prod_Brand = prod_Brand;
		Prod_Description = prod_Description;
		Prod_Price = prod_Price;
		Prod_Discount = prod_Discount;
		Prod_ConPrice = prod_ConPrice;
		Prod_Quantity = prod_Quantity;
		Prod_Promo = prod_Promo;
		Prod_Tax = prod_Tax;
		Prod_Deliverycharges = prod_Deliverycharges;
		Prod_FinalPrice = prod_FinalPrice;
	}

	public int getProd_Id() {
		return Prod_Id;
	}

	public void setProd_Id(int prod_Id) {
		Prod_Id = prod_Id;
	}

	public String getProd_Category() {
		return Prod_Category;
	}

	public void setProd_Category(String prod_Category) {
		Prod_Category = prod_Category;
	}

	public String getProd_Type() {
		return Prod_Type;
	}

	public void setProd_Type(String prod_Type) {
		Prod_Type = prod_Type;
	}

	public String getProd_SubType() {
		return Prod_SubType;
	}

	public void setProd_SubType(String prod_SubType) {
		Prod_SubType = prod_SubType;
	}

	public String getProd_Brand() {
		return Prod_Brand;
	}

	public void setProd_Brand(String prod_Brand) {
		Prod_Brand = prod_Brand;
	}

	public String getProd_Description() {
		return Prod_Description;
	}

	public void setProd_Description(String prod_Description) {
		Prod_Description = prod_Description;
	}

	public double getProd_Price() {
		return Prod_Price;
	}

	public void setProd_Price(double prod_Price) {
		Prod_Price = prod_Price;
	}

	public double getProd_Discount() {
		return Prod_Discount;
	}

	public void setProd_Discount(int prod_Discount) {
		Prod_Discount = prod_Discount;
	}

	public double getProd_ConPrice() {
		return Prod_ConPrice;
	}

	public void setProd_ConPrice(double prod_ConPrice) {
		Prod_ConPrice = prod_ConPrice;
	}

	public double getProd_Quantity() {
		return Prod_Quantity;
	}

	public void setProd_Quantity(int prod_Quantity) {
		Prod_Quantity = prod_Quantity;
	}

	public String getProd_Promo() {
		return Prod_Promo;
	}

	public void setProd_Promo(String prod_Promo) {
		Prod_Promo = prod_Promo;
	}

	public double getProd_Tax() {
		return Prod_Tax;
	}

	public void setProd_Tax(int prod_Tax) {
		Prod_Tax = prod_Tax;
	}

	public double getProd_Deliverycharges() {
		return Prod_Deliverycharges;
	}

	public void setProd_Deliverycharges(int prod_Deliverycharges) {
		Prod_Deliverycharges = prod_Deliverycharges;
	}

	public double getProd_FinalPrice() {
		return Prod_FinalPrice;
	}

	public void setProd_FinalPrice(double prod_FinalPrice) {
		Prod_FinalPrice = prod_FinalPrice;
	}

	@Override
	public String toString() {
		return "Invoice [Prod_Id=" + Prod_Id + ", Prod_Category=" + Prod_Category + ", Prod_Type=" + Prod_Type
				+ ", Prod_SubType=" + Prod_SubType + ", Prod_Brand=" + Prod_Brand + ", Prod_Description="
				+ Prod_Description + ", Prod_Price=" + Prod_Price + ", Prod_Discount=" + Prod_Discount
				+ ", Prod_ConPrice=" + Prod_ConPrice + ", Prod_Quantity=" + Prod_Quantity + ", Prod_Promo=" + Prod_Promo
				+ ", Prod_Tax=" + Prod_Tax + ", Prod_Deliverycharges=" + Prod_Deliverycharges + ", Prod_FinalPrice="
				+ Prod_FinalPrice + "]";
	}

}*/
package com.cg.model;
import java.sql.Date;
import java.time.LocalDate;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Table(name="discount")
public class Discount
{
@Id
@GeneratedValue(strategy = GenerationType.AUTO)

int id;
Date startTime;
Date endTime;
int discountPercentage;
float discountedPrice;
public float getDiscountedPrice() {
return discountedPrice;
}
public void setDiscountedPrice(float discountedPrice) {
this.discountedPrice = discountedPrice;
}
public int getId() {
return id;
}
public void setId(int id) {
this.id = id;
}
public Date getStartTime() {
return startTime;
}
public void setStartTime(Date startTime) {
this.startTime = Date.valueOf(LocalDate.now());
}
public Date getEndTime() {
return endTime;
}
public void setEndTime(Date endTime) {
this.endTime = endTime;
}
public int getDiscountPercentage() {
return discountPercentage;
}
public void setDiscountPercentage(int discountPercentage) {
this.discountPercentage = discountPercentage;
}

@Override
public String toString() {
return "Discount [id=" + id + ", startTime=" + startTime + ", endTime=" + endTime + ", discountPercentage=" + discountPercentage + ", discountedPrice=" + discountedPrice + "]";
}
}
